package com.cg.appl.commons;

public class CompanyDetails {
	
	
	
	private String companyName;
	private String companyMoto;
	private int niftyRank;
	private Address addr;
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {  //companyName=property name
		this.companyName = companyName;
	}
	public String getCompanyMoto() {
		return companyMoto;
	}
	public void setCompanyMoto(String companyMoto) {  //companyMoto=property name
		this.companyMoto = companyMoto;
	}
	public int getNiftyRank() {
		return niftyRank;
	}
	public void setNiftyRank(int niftyRank) {     ////niftyRank=property name
		this.niftyRank = niftyRank;
	}
	

	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMoto="
				+ companyMoto + ", niftyRank=" + niftyRank + ", addr=" + addr
				+ "]";
	}
	
	
	
	
	
	
	
	
	
	
	

}
