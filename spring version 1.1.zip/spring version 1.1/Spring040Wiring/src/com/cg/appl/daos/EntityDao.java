package com.cg.appl.daos;

import com.cg.appl.util.DbUtil;

public class EntityDao {

	private DbUtil dbUtil;
	
	
	public EntityDao()
	{
		System.out.println("in the constructor of entity dao");
		
	
	}
	
	public void setDbUtil1(DbUtil dbUtil){
	System.out.println("In setter of entity dao");
	this.dbUtil=dbUtil;
	
	
}

	public void getConnection(){
		
		dbUtil.getConnection();
		
	}
	
}
	