package com.cg.appl.util;

import java.sql.Connection;

public class JndiUtilImpl implements DbUtil {

	
	public JndiUtilImpl(){
		
		System.out.println("In the Constructor of jndi util");
		
	}
	
	@Override
	public Connection getConnection() {
		System.out.println("inside get Connection method");
		return null;
	}

}
