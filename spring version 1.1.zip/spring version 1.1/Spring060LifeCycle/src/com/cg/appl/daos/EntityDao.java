package com.cg.appl.daos;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;

@Repository("entityDao")
public class EntityDao {

	private DbUtil dbUtil;
	
	
	public EntityDao()
	{
		System.out.println("in the constructor of entity dao");
		
	
	}
	@PostConstruct
	public void setup()
	{
		
	System.out.println("In setup method of Dao");	
		
	}	
	
	@PreDestroy
	public void cleanup(){
		
		System.out.println("In cleanup of Dao");
		
	}
	
	/*@Autowired
	@Qualifier("dbUtil1")*/
	@Resource(name="dbUtil")
	public void setDbUtil(DbUtil dbUtil){
	System.out.println("In setter of entity dao");
	this.dbUtil=dbUtil;
	
	
}

	public void getConnection(){
	
		dbUtil.getConnection();
		
	}
	
}
	