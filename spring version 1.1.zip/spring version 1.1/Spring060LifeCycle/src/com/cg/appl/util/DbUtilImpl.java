package com.cg.appl.util;

import java.sql.Connection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class DbUtilImpl implements DbUtil , InitializingBean , DisposableBean , ApplicationContextAware{

	private ApplicationContext ctx;
	 
	public void setup(){
		
		
		System.out.println("In setup");
	} 
	
	
	
	public DbUtilImpl(){
		
		System.out.println("In constructor of DbUtil");
		
	}

	
	public void setX(int x){
		
		
		System.out.println("In X");
	}
	
	
	@Override
	public Connection getConnection() {
		System.out.println("In getConnection method");
		return null;
	}
	
	
	public void cleanup(){
		
		System.out.println("In cleanup");
	}



	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("In after property set");
		
	}



	@Override
	public void destroy() throws Exception {
	System.out.println("In destroy method");
	}



	@Override
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
         System.out.println("In application context aware");	
         ctx=arg0;
	}
}
