package com.cg.appl.commons;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("companyDetails")
public class CompanyDetails {
    
	@Value("Capgemini")
	private String companyName;
	
	@Value("health is wealth")
	private String companyMoto;
	
	@Value("007")
	private int niftyRank;
	
	@Resource
	private Address addr;
	
	private List<String>directors;
	
	private Set<String>branches;
	
	private Map<String,String>branchAddr;
	
	private Properties ipAddresses;
	
	
	public CompanyDetails(int niftyRank,String companyMoto,Address addr){
		
		System.out.println("In the constructor for int and String");
		this.niftyRank = niftyRank;	
		this.companyMoto = companyMoto;	
		this.addr=addr;
	}
	
	public CompanyDetails (){
		
		
		
	}
	
public CompanyDetails(String companyMoto){
		
		System.out.println("In the constructor for String");
		this.companyMoto = companyMoto;	
	}
	

	public String getCompanyName() {
		return companyName;
	}
	
	public void setCompanyName(String companyName) {  //companyName=property name
		this.companyName = companyName;
	}
	public String getCompanyMoto() {
		return companyMoto;
	}
	public void setCompanyMoto(String companyMoto) {  //companyMoto=property name
		this.companyMoto = companyMoto;
	}
	public int getNiftyRank() {
		return niftyRank;
	}
	public void setNiftyRank(int niftyRank) {     ////niftyRank=property name
		this.niftyRank = niftyRank;
	}
	

	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	public Set<String> getBranches() {
		return branches;
	}

	public void setBranches(Set<String> branches) {
		this.branches = branches;
	}

	public List<String> getDirectors() {
		return directors;
	}

	public void setDirectors(List<String> directors) {
		this.directors = directors;
	}


	public Map<String, String> getBranchAddr() {
		return branchAddr;
	}

	public void setBranchAddr(Map<String, String> branchAddr) {
		this.branchAddr = branchAddr;
	}

	public Properties getIpAddresses() {
		return ipAddresses;
	}

	public void setIpAddresses(Properties ipAddresses) {
		this.ipAddresses = ipAddresses;
	}

	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMoto="
				+ companyMoto + ", niftyRank=" + niftyRank + ", addr=" + addr
				+ ",\n directors=" + directors + ", \n branches=" + branches
				+ ", branchAddr=" + branchAddr + ", \n ipAddresses=" + ipAddresses
				+ "]";
	}
	
	
	
	
	
	
	
	
	
	
	

}
