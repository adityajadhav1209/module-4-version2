package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;


import com.cg.appl.commons.Results;
import com.cg.appl.util.SpringUtil;

public class TestEl {

	public static void main(String[] args) {
	
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		Results results = (Results) ctx.getBean("results");
		
		System.out.println(results);

	}

}
