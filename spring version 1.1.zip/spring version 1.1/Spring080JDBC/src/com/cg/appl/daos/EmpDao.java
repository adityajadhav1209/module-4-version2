package com.cg.appl.daos;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

public interface EmpDao {

	
	Emp getEmpdetails(int empNo) throws EmpExceptions;
	
}
