package com.cg.appl.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.util.EntitymanageUtil;



//Component:For every class
//Service: For Service class
//Repository: For Dao class
//Controller : For controller classes of spring mvc
//RestController : to declare controller classes for publishing REST services

//@Component("empDao")
public class EmpDaoImpl implements EmpDao {

	
	private DataSource datasource;
	
	
	
	
	public EmpDaoImpl(){
		
		System.out.println("In constructor of EmpDaoImpl");
	}
	
/*	
	public EntitymanageUtil getUtil() {
		return util;
	}
*/
    
	@Resource(name="datasource")
	public void setDataSource(DataSource datasource) {
		System.out.println("In SetUtil");
		this.datasource = datasource;
	}


	@Override
	public Emp getEmpdetails(int empNo) throws EmpExceptions {
		System.out.println("In getEmpDetails()");
		Connection connect=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Emp emp = new Emp();
		String qry="SELECT EMPNO,ENAME,SAL FROM EMP WHERE EMPNO=?";
		try {
			connect = datasource.getConnection();
			pstmt=connect.prepareStatement(qry);
			pstmt.setInt(1, empNo);
			rs=pstmt.executeQuery();
			
			if(rs.next()){
				
				
				emp.setEmpNo(rs.getInt("EMPNO"));
				emp.setEmpNm(rs.getString("ENAME"));
				emp.setEmpSal(rs.getFloat("SAL"));
				
				return emp;
			}
			
			
		} catch (SQLException e) {
			throw new EmpExceptions("problem in database handling",e);
		}finally{
			
			try {
				if(rs!=null){
					
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(connect!=null)
				{
					connect.close();
				}
			} catch (SQLException e) {
				throw new EmpExceptions("problem in database closing",e);
			}			
		}
		
		return null;
	}

}
