package com.cg.appl.daos;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;


@Repository("empDao")
public class EmpDaoJdbcTmpl implements EmpDao{

	
	private JdbcTemplate template;
	
	@Resource(name="jdbcTemplate")
	public void setTemplate(JdbcTemplate template){
		
		
		
		this.template=template;
		
		
	}


	@Override
	public Emp getEmpdetails(int empNo) throws EmpExceptions {
		
		String qry="SELECT EMPNO,ENAME,SAL FROM EMP WHERE EMPNO=?";
		Object[]params = {7499};
		/*List<Map<String,Object>> empList = template.queryForList(qry, params);
		Map<String,Object> mapEmp = empList.get(0);
		Emp emp = new Emp();
		BigDecimal deci = (BigDecimal) mapEmp.get("EMPNO");
		emp.setEmpNo(deci.intValue());
		emp.setEmpNm((String)mapEmp.get("ENAME"));
		
		emp.setEmpSal(((BigDecimal)mapEmp.get("SAL")).floatValue());*/
		
		Emp emp = template.queryForObject(qry, mapper,params);
		return emp;
	}
	
	private ParameterizedRowMapper<Emp> mapper = new ParameterizedRowMapper<Emp>(){
			
	
	@Override
	public Emp mapRow(ResultSet rs,int rowNum) {
		
		  Emp emp = new Emp();
		
		try {
			emp.setEmpNo(rs.getInt("EMPNO"));
			emp.setEmpNm(rs.getString("ENAME"));
			emp.setEmpSal(rs.getFloat("SAL"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}
	};
	
}
