package com.cg.appl.exceptions;

public class EmpExceptions extends Exception {

	private static final long serialVersionUID = 1L;

	public EmpExceptions() {
	
	}

	public EmpExceptions(String message) {
		super(message);

	}

	public EmpExceptions(Throwable cause) {
		super(cause);

	}

	public EmpExceptions(String message, Throwable cause) {
		super(message, cause);
	
	}

	public EmpExceptions(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

}
