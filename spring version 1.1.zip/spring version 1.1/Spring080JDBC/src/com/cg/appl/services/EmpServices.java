package com.cg.appl.services;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

public interface EmpServices {
	Emp getEmpdetails(int empNo) throws EmpExceptions;
}
