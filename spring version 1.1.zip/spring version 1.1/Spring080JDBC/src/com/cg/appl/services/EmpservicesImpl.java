package com.cg.appl.services;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;

@Component("empService")
public class EmpservicesImpl implements EmpServices {

	
	
	private EmpDao dao;
	
	public EmpservicesImpl(){
		
		
		System.out.println("In Constructor of EmpservicesImpl");
		
	}
	
	

    @Resource(name="empDao")
	//@Autowired
	//@Qualifier("dbUtil")
	public void setDao(EmpDao dao) {
		System.out.println("In SetDao");
		this.dao = dao;
	}





	@Override
	public Emp getEmpdetails(int empNo) throws EmpExceptions {
		
		return dao.getEmpdetails(empNo);
	}

}
