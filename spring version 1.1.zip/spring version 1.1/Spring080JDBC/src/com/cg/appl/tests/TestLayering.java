package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpExceptions;
import com.cg.appl.services.EmpServices;
import com.cg.appl.util.SpringUtil;

public class TestLayering {

	public static void main(String[] args) {
		
		
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		
		
		EmpServices empServices = ctx.getBean("empService", EmpServices.class);
		
		
		try {
		Emp emp=empServices.getEmpdetails(7499);
		System.out.println(emp);
		} catch (EmpExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
