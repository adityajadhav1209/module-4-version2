package com.cg.appl.util;


import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringUtil {
	
	
private ConfigurableApplicationContext context;	
	
public SpringUtil(){
	
	context = new ClassPathXmlApplicationContext("CompanyHr.xml");	
		
}


public ConfigurableApplicationContext getSpringContext(){
	
	return context;
	
	
}
	

}
