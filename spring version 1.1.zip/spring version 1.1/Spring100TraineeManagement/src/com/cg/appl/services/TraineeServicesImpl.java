package com.cg.appl.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.daos.TraineeDaoImpl;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;


@Service("traineeService")
public class TraineeServicesImpl implements TraineeServices {

	
	private TraineeDao dao;

	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		
		this.dao=dao;
		
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		return dao.getTraineeDetails(traineeId);
	}

}
