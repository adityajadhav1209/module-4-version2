package com.cg.appl.tests;

import org.springframework.context.ConfigurableApplicationContext;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;
import com.cg.appl.util.SpringUtil;

public class TestSpringJpa {

	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ConfigurableApplicationContext ctx = util.getSpringContext();
		
		TraineeServices services = ctx.getBean("traineeService",TraineeServices.class) ;
		
		try {
			Trainee trainee = services.getTraineeDetails(1000);
			System.out.println(trainee);
		} catch (TraineeException e) {
			
			e.printStackTrace();
		}
		
		
		
		ctx.close();
		

	}

}
