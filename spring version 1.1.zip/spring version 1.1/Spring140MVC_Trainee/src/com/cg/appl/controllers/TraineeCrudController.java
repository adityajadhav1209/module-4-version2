package com.cg.appl.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;




@Controller
public class TraineeCrudController {

	
	private TraineeServices services;
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		
		
		this.services=services;
	}
	
	
	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){
		
		ModelAndView model = new ModelAndView("enterTraineeNo");
		return model;
		
	}
	
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){
		
		System.out.println("In Controlling method:" +traineeNo);
		
		ModelAndView model=null;
		try {
			Trainee trainee = services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("trainee",trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
		
	}
	
	@RequestMapping("/listAllTrainees.do")
	public ModelAndView listAllTrainees(){
    ModelAndView model=null;	
	try {
		List<Trainee> trainees = services.getAllTrainees();
		model = new ModelAndView("listAllTrainees");
		model.addObject("trainees", trainees);
	} catch (TraineeException e) {
		model = new ModelAndView("error");
		model.addObject("errMsg", e.getMessage());
	}
	
	return model;
	
		
		
	}
	
	
}
