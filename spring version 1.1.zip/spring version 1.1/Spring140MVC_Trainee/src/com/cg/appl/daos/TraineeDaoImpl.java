package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {

	private EntityManagerFactory factory;
	
	
	@Resource(name="entityMFactory")
    public void setEntityMFactory(EntityManagerFactory factory){
    	
    	this.factory=factory;
    	
    }

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
	
		
		EntityManager manager = factory.createEntityManager();
		Trainee trainee = manager.find(Trainee.class, traineeId);
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		String qryStr = "select t from trainee t";
		EntityManager manager = factory.createEntityManager();
		Query qry = manager.createQuery(qryStr, Trainee.class);
		
		return qry.getResultList();
	}

}
