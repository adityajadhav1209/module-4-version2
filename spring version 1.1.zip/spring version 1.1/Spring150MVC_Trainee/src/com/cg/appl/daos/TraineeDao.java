package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

public interface TraineeDao {


 Trainee getTraineeDetails(int traineeId)throws TraineeException;
 List<Trainee>getAllTrainees()throws TraineeException;
 Trainee addTraineeDetails(Trainee trainee )throws TraineeException;
 Trainee updateTrainee(Trainee trainee)throws TraineeException; 
boolean deleteTrainee(int traineeId)throws TraineeException;



}
