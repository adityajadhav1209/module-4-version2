package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.daos.TraineeDaoImpl;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;


@Service("traineeService")
public class TraineeServicesImpl implements TraineeServices {

	
	private TraineeDao dao;

	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		
		this.dao=dao;
		
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		
		return dao.getAllTrainees();
	}

	
	@Transactional
	@Override
	public Trainee addTraineeDetails(Trainee trainee) throws TraineeException {
		
		return dao.addTraineeDetails(trainee);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.updateTrainee(trainee);
	}

	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(traineeId);
	}

	

}
